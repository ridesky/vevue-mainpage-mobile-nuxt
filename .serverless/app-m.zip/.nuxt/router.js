import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

const _28a5aae2 = () => import('..\\src\\pages\\main.vue' /* webpackChunkName: "pages_main" */).then(m => m.default || m)
const _10b414ae = () => import('..\\src\\pages\\task.vue' /* webpackChunkName: "pages_task" */).then(m => m.default || m)
const _f42972a6 = () => import('..\\src\\pages\\unlock.vue' /* webpackChunkName: "pages_unlock" */).then(m => m.default || m)
const _5eb9467f = () => import('..\\src\\pages\\focus.vue' /* webpackChunkName: "pages_focus" */).then(m => m.default || m)
const _fb19df0a = () => import('..\\src\\pages\\history.vue' /* webpackChunkName: "pages_history" */).then(m => m.default || m)
const _876dc6f4 = () => import('..\\src\\pages\\pin\\index.vue' /* webpackChunkName: "pages_pin_index" */).then(m => m.default || m)
const _396d3a6e = () => import('..\\src\\pages\\message.vue' /* webpackChunkName: "pages_message" */).then(m => m.default || m)
const _161db93a = () => import('..\\src\\pages\\likes.vue' /* webpackChunkName: "pages_likes" */).then(m => m.default || m)
const _341f072a = () => import('..\\src\\pages\\setting\\index.vue' /* webpackChunkName: "pages_setting_index" */).then(m => m.default || m)
const _661781fb = () => import('..\\src\\pages\\playlist.vue' /* webpackChunkName: "pages_playlist" */).then(m => m.default || m)
const _2e8d3c1c = () => import('..\\src\\pages\\login\\index.vue' /* webpackChunkName: "pages_login_index" */).then(m => m.default || m)
const _ec6c338a = () => import('..\\src\\pages\\login\\countries.js' /* webpackChunkName: "pages_login_countries" */).then(m => m.default || m)
const _4e2e948e = () => import('..\\src\\pages\\video\\_videoid.vue' /* webpackChunkName: "pages_video__videoid" */).then(m => m.default || m)
const _2450a67e = () => import('..\\src\\pages\\follow\\_towho.vue' /* webpackChunkName: "pages_follow__towho" */).then(m => m.default || m)
const _d5b3afea = () => import('..\\src\\pages\\follow\\_towho\\_type.vue' /* webpackChunkName: "pages_follow__towho__type" */).then(m => m.default || m)
const _2fe38050 = () => import('..\\src\\pages\\user\\_towho.vue' /* webpackChunkName: "pages_user__towho" */).then(m => m.default || m)
const _ffba516c = () => import('..\\src\\pages\\user\\towho\\_type.vue' /* webpackChunkName: "pages_user_towho__type" */).then(m => m.default || m)
const _64f6e50e = () => import('..\\src\\pages\\index.vue' /* webpackChunkName: "pages_index" */).then(m => m.default || m)



if (process.client) {
  window.history.scrollRestoration = 'manual'
}
const scrollBehavior = function (to, from, savedPosition) {
  // if the returned position is falsy or an empty object,
  // will retain current scroll position.
  let position = false

  // if no children detected
  if (to.matched.length < 2) {
    // scroll to the top of the page
    position = { x: 0, y: 0 }
  } else if (to.matched.some((r) => r.components.default.options.scrollToTop)) {
    // if one of the children has scrollToTop option set to true
    position = { x: 0, y: 0 }
  }

  // savedPosition is only available for popstate navigations (back button)
  if (savedPosition) {
    position = savedPosition
  }

  return new Promise(resolve => {
    // wait for the out transition to complete (if necessary)
    window.$nuxt.$once('triggerScroll', () => {
      // coords will be used if no selector is provided,
      // or if the selector didn't match any element.
      if (to.hash) {
        let hash = to.hash
        // CSS.escape() is not supported with IE and Edge.
        if (typeof window.CSS !== 'undefined' && typeof window.CSS.escape !== 'undefined') {
          hash = '#' + window.CSS.escape(hash.substr(1))
        }
        try {
          if (document.querySelector(hash)) {
            // scroll to anchor by returning the selector
            position = { selector: hash }
          }
        } catch (e) {
          console.warn('Failed to save scroll position. Please add CSS.escape() polyfill (https://github.com/mathiasbynens/CSS.escape).')
        }
      }
      resolve(position)
    })
  })
}


export function createRouter () {
  return new Router({
    mode: 'history',
    base: '/',
    linkActiveClass: 'nuxt-link-active',
    linkExactActiveClass: 'nuxt-link-exact-active',
    scrollBehavior,
    routes: [
		{
			path: "/main",
			component: _28a5aae2,
			name: "main"
		},
		{
			path: "/task",
			component: _10b414ae,
			name: "task"
		},
		{
			path: "/unlock",
			component: _f42972a6,
			name: "unlock"
		},
		{
			path: "/focus",
			component: _5eb9467f,
			name: "focus"
		},
		{
			path: "/history",
			component: _fb19df0a,
			name: "history"
		},
		{
			path: "/pin",
			component: _876dc6f4,
			name: "pin"
		},
		{
			path: "/message",
			component: _396d3a6e,
			name: "message"
		},
		{
			path: "/likes",
			component: _161db93a,
			name: "likes"
		},
		{
			path: "/setting",
			component: _341f072a,
			name: "setting"
		},
		{
			path: "/playlist",
			component: _661781fb,
			name: "playlist"
		},
		{
			path: "/login",
			component: _2e8d3c1c,
			name: "login"
		},
		{
			path: "/login/countries",
			component: _ec6c338a,
			name: "login-countries"
		},
		{
			path: "/video/:videoid?",
			component: _4e2e948e,
			name: "video-videoid"
		},
		{
			path: "/follow/:towho?",
			component: _2450a67e,
			name: "follow-towho",
			children: [
				{
					path: ":type?",
					component: _d5b3afea,
					name: "follow-towho-type"
				}
			]
		},
		{
			path: "/user/:towho?",
			component: _2fe38050,
			name: "user-towho",
			children: [
				{
					path: ":type?",
					component: _ffba516c,
					name: "user-towho-type"
				}
			]
		},
		{
			path: "/",
			component: _64f6e50e,
			name: "index"
		}
    ],
    
    
    fallback: false
  })
}
