'use strict';
const awsServerlessExpress = require('aws-serverless-express')
const app = require('./server')

const binaryMimeTypes = [
  'application/javascript',
  'application/json',
  'application/octet-stream',
  'application/xml',
  'font/eot',
  'application/font-woff',
  'font/woff2',
  'font/opentype',
  'font/otf',
  'image/jpeg',
  'image/png',
  'image/gif',
  'image/x-icon',
  'image/svg+xml',
  'text/comma-separated-values',
  'text/css',
  'text/html',
  'text/javascript',
  'text/plain',
  'text/text',
  'text/xml'
]
const server = awsServerlessExpress.createServer(app, null, binaryMimeTypes)

module.exports.nuxt = (event, context) => awsServerlessExpress.proxy(server, event, context)
