<template>
  <div class="absolutecenter">
  </div>
</template>

<script>
export default {
  asyncData(context) {
    context.redirect('/main');
  }
};
</script>